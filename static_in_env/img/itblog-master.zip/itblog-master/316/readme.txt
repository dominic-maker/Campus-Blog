Android + Django REST Framework update post. Android Client

cd django-project
source bin/activate
cd newproject
python manage.py runserver
python manage.py runserver 192.168.0.174:8000
192.168.0.174:8000/rest/1/edit
192.168.0.174:8000
192.168.0.174
