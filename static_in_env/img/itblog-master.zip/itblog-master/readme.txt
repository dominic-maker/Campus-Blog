www.it.anar8.ru

Youtube
https://www.youtube.com/LinuxWayKungFu

React Native blog
https://www.facebook.com/ReactNativeBlog/

Python Blog
https://www.facebook.com/groups/python4/

Android Blog
https://www.facebook.com/androidKungFu/