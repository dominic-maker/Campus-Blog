React Native + Django rest application DestroyApiView. React Native client part 3.

Back-end Part 1.
https://www.youtube.com/watch?v=CIU2MpXxyzw

expo init django-client
cd django-client
expo start
