from django.contrib import admin
from user_app.models import MyUser


admin.site.register(MyUser)