React Native + Django rest application CreateApiView. React Native client part 3.


expo init django-client
cd django-client
expo start
