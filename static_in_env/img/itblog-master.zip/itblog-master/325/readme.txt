Android + Django rest application CreateApiView. Android client part 2.
