Android, React Native + Django rest application ListAPIView. React Native client part 3.

Back-end Part 1.
https://www.youtube.com/watch?v=fB42IgeOrlk

expo init django-client
cd django-client
expo start
