Android + Django rest application DestroyApiView. Android client part 2.

Back-end Part 1.
https://www.youtube.com/watch?v=CIU2MpXxyzw