from django.contrib import admin
from image_app.models import MyImage


admin.site.register(MyImage)
