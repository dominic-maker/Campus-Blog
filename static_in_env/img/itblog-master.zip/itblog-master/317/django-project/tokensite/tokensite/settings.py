ALLOWED_HOSTS = [
    '192.168.0.112',
]

INSTALLED_APPS = [
    'rest_framework.authtoken',
    'rest_framework',

    'blog',
]
