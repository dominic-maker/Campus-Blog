from django.contrib import admin
from helloworld.models import Post

admin.site.register(Post)
