Android, React Native + Django rest application ListAPIView. Android client part 2.

Back-end Part 1.
https://www.youtube.com/watch?v=fB42IgeOrlk