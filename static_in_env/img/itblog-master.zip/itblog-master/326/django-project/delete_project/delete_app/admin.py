from django.contrib import admin
from delete_app.models import Post


admin.site.register(Post)