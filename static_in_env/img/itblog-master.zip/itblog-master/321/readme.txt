Android + Django REST Framework image upload. Android Client part 2 
https://www.youtube.com/watch?v=uWG5fMtaRYM

Back-end Django Part1
https://www.youtube.com/watch?v=huC3XQoUZiU