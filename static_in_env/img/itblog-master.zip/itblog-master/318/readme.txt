Token Based Authentication for Django Rest Framework + Android Client. Android Client
