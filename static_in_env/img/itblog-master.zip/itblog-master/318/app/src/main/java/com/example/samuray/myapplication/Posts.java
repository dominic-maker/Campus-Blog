package com.example.samuray.myapplication;


public class Posts {

    private String title;
    private String text;


    public Posts(String title, String text) {
        this.title = title;
        this.title = text;
    }


    public String getTitle(){
        return title;
    }

    public String getText(){
        return text;
    }

}
