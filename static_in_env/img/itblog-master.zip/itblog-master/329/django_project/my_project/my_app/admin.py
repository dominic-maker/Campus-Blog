from django.contrib import admin
from my_app.models import Post


admin.site.register(Post)